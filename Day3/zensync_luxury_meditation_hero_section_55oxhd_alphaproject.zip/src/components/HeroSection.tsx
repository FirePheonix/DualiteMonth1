import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative w-full h-screen overflow-hidden">
      {/* Background Video Container */}
      <div className="absolute inset-0 w-full h-full">
        {/* Placeholder for background video - User will replace this with their video */}
        <div className="w-full h-full bg-gradient-to-br from-gray-900 via-gray-800 to-black">
          {/* This would be replaced with actual video element */}
          <video
            className="w-full h-full object-cover"
            autoPlay
            loop
            muted
            playsInline
          >
            {/* User will add their video source here */}
            <source src="/path-to-your-video.mp4" type="video/mp4" />
          </video>
        </div>
        
        {/* Dark overlay for contrast */}
        <div className="absolute inset-0 bg-black/50"></div>
      </div>

      {/* Content Container - Positioned at bottom */}
      <div className="absolute bottom-0 left-0 right-0 z-10 px-6 md:px-8 lg:px-12">
        
        {/* Decorative Line */}
        <div className="w-full mb-6 md:mb-8">
          <div className="h-px bg-gradient-to-r from-white/60 via-white/30 to-transparent max-w-screen-xl"></div>
        </div>

        {/* Bottom Content Area */}
        <div className="pb-6 md:pb-8 lg:pb-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-12 max-w-screen-xl">
            
            {/* Left Side - Main Title and Subtitle */}
            <div className="space-y-3 md:space-y-4">
              <h1 className="text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-light text-white leading-[0.95] tracking-tight font-elegant">
                Experience Inner Peace<br />
                Like Never Before
              </h1>
              
              <div className="space-y-2 max-w-lg">
                <p className="text-sm md:text-base text-white/90 leading-relaxed font-light">
                  Breathe deeply. Be fully present. Rediscover tranquility with ZenSync.
                </p>
              </div>
            </div>

            {/* Right Side - Description */}
            <div className="flex items-end lg:justify-end">
              <div className="max-w-md lg:max-w-sm space-y-2">
                <p className="text-xs md:text-sm text-white/70 leading-relaxed font-light">
                  Explore what it means to truly be — where stillness meets luxury.
                </p>
                <p className="text-xs md:text-sm text-white/70 leading-relaxed font-light">
                  ZenSync is more than meditation. It's a lifestyle of presence, peace, and purpose — whether you're in your sanctuary, on a retreat, or simply taking a mindful pause in your day.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
